﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Number_Guesser
{
    internal class Validator
    {
        //This class will check, if the user input is correct or if he/she tries to write a number over 100 or under 0.

        public static void ValidateGuess(string mode, string nameTeam1, string nameTeam2, int guess, int number, ref int numOfGuess)
        {
            //This piece of code was written by Marek von Rogall
            int currentTeam = numOfGuess % 2;
            //-------------------------------

            if (guess < 1 || guess > 100)
            {
                Console.Write("The number you wrote is not between 1 and 100, please use numbers between 1 and 100 only. ");
                numOfGuess++;
            }
            else if (guess > number)
            {
                Console.Write("The number you guessed is incorrect, try lower! ");
                numOfGuess++;
            }
            else if (guess < number)
            {
                Console.Write("The number you guessed is incorrect, try higher! ");
                numOfGuess++;
            }
           
            if (mode == "b" && number != guess)
            {
                // This piece of code was written by Marek von Rogall
                if (currentTeam == 1)
                {
                    Console.Write("It's team {0}'s turn: ", nameTeam1);
                }
                else { Console.Write("It's team {0}'s turn: ", nameTeam2); }
                //------------------------------------------------
            }          
        }
    }
}
