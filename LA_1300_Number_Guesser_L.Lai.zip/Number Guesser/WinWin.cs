﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Number_Guesser
{
    internal class WinWin
    {
        //This class checks which team won the match.
        public static void DetermineWinner(string mode, string teamName1, string teamName2, int team1Guesses, int team2Guesses)
        {
            int totalTeam1Guesses = team1Guesses % 2;
            int totalTeam2Guesses = team2Guesses % 2;

            if (mode == "b")
            {
                if (totalTeam2Guesses > 0)
                {
                    Console.WriteLine("Team {0} wins!", teamName2);
                }
                else if (totalTeam1Guesses > 1)
                {
                    Console.WriteLine("Team {0} wins!", teamName1);
                }
            }         
        }
    }
}
