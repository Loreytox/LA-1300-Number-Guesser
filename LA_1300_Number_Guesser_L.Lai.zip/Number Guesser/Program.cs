﻿using System.Numerics;
using System;
using System.Reflection.Metadata.Ecma335;

namespace Number_Guesser
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool playAg = true;

            do
            {
                Team team = new Team();
                string mode;              
                int guess = 0;
                int numOfGuess = 0;
                int numOfGuessTeam1 = 0;
                int numOfGuessTeam2 = 0;

                // I copied this piece of code from StackOverflow 
                Random rand = new Random();
                int number = rand.Next(0, 100);
                //-----------------------------

                Console.Write("Please choose between singleplayer and multiplayer (a/b): ");

                do
                {
                    mode = Console.ReadLine();

                    if (mode == "a" || mode == "b")
                    {
                        team.ChooseTeam(mode);
                    }
                    else
                    {
                        Console.Write("Please use only a (singleplayer) or b (multiplayer): ");
                    }

                } while (mode != "a" && mode != "b");

                do
                {
                    // This piece of code is not from me, but from ChatGPT, as i didn't know how to implement my method into the main program.
                    try
                    {
                        guess = Convert.ToInt32(Console.ReadLine());
                        Validator.ValidateGuess(mode, team.team1, team.team2, guess, number, ref numOfGuess);
                    }
                    catch
                    {
                        Console.Write("Please restrain from using letters, only numbers between 1 and 100: ");
                        numOfGuess++;
                    }
                    //------------------------------------------------------------------------------------------------------
                } while (guess != number);

                WinWin.DetermineWinner(mode, team.team1, team.team2, numOfGuess + 1, numOfGuessTeam1 + numOfGuessTeam2 + 1);
                Console.Write("It took {0} tries to guess the correct number. Would you like to play again (y/n)?", numOfGuess + 1);
                string playAgainInput = Console.ReadLine();

                if (playAgainInput != "y")
                {
                    playAg = false;
                    Console.WriteLine("Thank you for playing.");
                }
                
            } while (playAg);
        }
    }
}