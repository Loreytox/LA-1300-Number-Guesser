﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Number_Guesser
{
    internal class Team
    {
        //This class will check if the player has chosen singleplayer or multiplayer and will allow him/her to choose a name for the teams.
        //It will also only accept 'a' or 'b' when asking for sinnglee/multiplayer.

        public string team1;
        public string team2;

        public void ChooseTeam (string mode)
        {
            if (mode == "a")
            {
                Console.Write("You have chosen singleplayer mode, try to guess the hidden number.: ");
            }
            else if (mode == "b")
            {
                Console.Write("You have chosen multiplayer mode, please name team Nr.1: ");
                team1 = Console.ReadLine();
            
                Console.Write("Team {0} has joined the game, please name team Nr.2: ", team1);
                team2 = Console.ReadLine();
            
                Console.Write("Team {0} and Team {1} have joined the party. Team {0} will begin: ", team1, team2);
            }
            else if (mode != "a" || mode != "b")
            {
                Console.Write("Please use only a (singleplayer) or b (multiplayer): ");
            }
        }
    }
}
